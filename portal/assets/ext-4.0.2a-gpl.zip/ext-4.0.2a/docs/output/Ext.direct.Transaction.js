Ext.data.JsonP.Ext_direct_Transaction({
  "mixedInto": [

  ],
  "superclasses": [

  ],
  "inheritable": false,
  "subclasses": [

  ],
  "deprecated": null,
  "allMixins": [

  ],
  "href": "Transaction.html#Ext-direct-Transaction",
  "members": {
    "cfg": [

    ],
    "method": [
      {
        "inheritable": false,
        "deprecated": null,
        "params": [
          {
            "type": "Object",
            "optional": true,
            "doc": "<p>(optional) Config object.</p>\n",
            "name": "config"
          }
        ],
        "href": "Transaction.html#Ext-direct-Transaction-method-constructor",
        "return": {
          "type": "Object",
          "doc": "\n"
        },
        "protected": false,
        "tagname": "method",
        "alias": null,
        "filename": "/mnt/ebs/nightly/git/SDK/platform/src/direct/Transaction.js",
        "private": false,
        "shortDoc": "Creates new Transaction. ...",
        "static": false,
        "name": "constructor",
        "owner": "Ext.direct.Transaction",
        "doc": "<p>Creates new Transaction.</p>\n",
        "linenr": 19,
        "html_filename": "Transaction.html"
      }
    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ],
    "property": [

    ]
  },
  "singleton": false,
  "protected": false,
  "tagname": "class",
  "mixins": [

  ],
  "alias": null,
  "author": null,
  "filename": "/mnt/ebs/nightly/git/SDK/platform/src/direct/Transaction.js",
  "private": false,
  "alternateClassNames": [
    "Ext.Direct.Transaction"
  ],
  "static": false,
  "name": "Ext.direct.Transaction",
  "doc": "<p>Supporting Class for Ext.Direct (not intended to be used directly).</p>\n\n",
  "docauthor": null,
  "component": false,
  "linenr": 1,
  "xtypes": [

  ],
  "html_filename": "Transaction.html",
  "statics": {
    "cfg": [

    ],
    "method": [

    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ],
    "property": [

    ]
  },
  "extends": "Object"
});