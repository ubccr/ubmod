Ext.data.JsonP.direct({
  "guide": "<h1>Ext Direct</h1>\n\n<hr />\n\n<iframe src=\"http://player.vimeo.com/video/17876920?byline=0&amp;portrait=0\" width=\"500\" height=\"281\" frameborder=\"0\"></iframe>\n\n"
});