Ext.data.JsonP.DOM({
  "guide": "<h1>The DOM</h1>\n\n<hr />\n"
});