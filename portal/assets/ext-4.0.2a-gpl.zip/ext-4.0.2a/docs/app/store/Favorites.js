/**
 * Favorites Store
 */
Ext.define('Docs.store.Favorites', {
    extend: 'Ext.data.Store',
    model: 'Docs.model.Favorite'
});
