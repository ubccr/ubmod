Ext.data.JsonP.drag_and_drop({
  "guide": "<h1>Drag and Drop</h1>\n\n<hr />\n"
});