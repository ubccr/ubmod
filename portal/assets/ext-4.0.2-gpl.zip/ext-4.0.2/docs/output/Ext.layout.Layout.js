Ext.data.JsonP.Ext_layout_Layout({
  "allMixins": [

  ],
  "deprecated": null,
  "docauthor": null,
  "members": {
    "cfg": [

    ],
    "method": [

    ],
    "property": [

    ],
    "cssVar": [

    ],
    "cssMixin": [

    ],
    "event": [

    ]
  },
  "singleton": false,
  "alias": null,
  "superclasses": [

  ],
  "protected": false,
  "tagname": "class",
  "mixins": [

  ],
  "href": "Layout.html#Ext-layout-Layout",
  "subclasses": [
    "Ext.layout.container.AbstractContainer"
  ],
  "static": false,
  "author": null,
  "component": false,
  "filename": "/mnt/ebs/nightly/git/SDK/platform/src/layout/Layout.js",
  "private": false,
  "alternateClassNames": [

  ],
  "name": "Ext.layout.Layout",
  "doc": "<p>Base Layout class - extended by ComponentLayout and ContainerLayout</p>\n",
  "mixedInto": [

  ],
  "linenr": 1,
  "xtypes": [

  ],
  "html_filename": "Layout.html",
  "extends": "Object"
});